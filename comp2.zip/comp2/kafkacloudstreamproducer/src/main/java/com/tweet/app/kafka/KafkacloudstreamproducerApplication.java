package com.tweet.app.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class KafkacloudstreamproducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkacloudstreamproducerApplication.class, args);
	}

}
