package com.tweet.app.kafka.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document
public class Reply {
    @Id
    private Long replyId;
    private Long tweetId;
    private String replyText;
    private String userLoginId;
    private String dateOfReply;
	public void setReplyId(Long timeMilli) {
		// TODO Auto-generated method stub
		
	}
	public Long getTweetId() {
		return tweetId;
	}
	public void setTweetId(Long tweetId) {
		this.tweetId = tweetId;
	}
	public String getReplyText() {
		return replyText;
	}
	public void setReplyText(String replyText) {
		this.replyText = replyText;
	}
	public String getUserLoginId() {
		return userLoginId;
	}
	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}
	public String getDateOfReply() {
		return dateOfReply;
	}
	public void setDateOfReply(String dateOfReply) {
		this.dateOfReply = dateOfReply;
	}
	public Long getReplyId() {
		return replyId;
	}

}
